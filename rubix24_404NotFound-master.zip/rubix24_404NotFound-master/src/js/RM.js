import React from 'react';
import './CSS/Chat.css'; // Import the CSS file

const RM = ({ m }) => {
  return (
    <div className="RM-container">
      <p>{m}</p>
    </div>
  );
};

export default RM;